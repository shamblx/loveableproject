import { LeadCapturePage } from '@/components/LeadCapturePage';

const Index = () => {
  return <LeadCapturePage />;
};

export default Index;
